from django.apps import AppConfig


class UsersConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'users'

    # connect the signals to the app
    # def ready(self):
    #     import users.signals
