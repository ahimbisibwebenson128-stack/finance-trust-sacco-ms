"""
URL configuration for backend project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from django.http import JsonResponse

def health_check(request):
    return JsonResponse({"status": "ok", "service": "FINANCE TRUST SACCO MS API"})


urlpatterns = [
    path("health/", health_check, name="health-check"),
    path('admin/', admin.site.urls),
    path('api/v1/auth/', include('users.urls')),
    path('api/v1/auth', include('rest_framework.urls', namespace='rest_framework')),
    path('api/v1/', include('members.urls')),
    path('api/v1/', include('accounts.urls')),
    path('api/v1/', include('loans.urls')),
    # Keeps the established customer and loan APIs available while the loan UI is built.
    # Accounts and transactions above take precedence over the legacy routes with the
    # same names; /customers/ remains unique while /loans/ is now owned by the loans app.
    path('api/v1/', include('customers.urls')),
]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL,
                          document_root=settings.MEDIA_ROOT)
